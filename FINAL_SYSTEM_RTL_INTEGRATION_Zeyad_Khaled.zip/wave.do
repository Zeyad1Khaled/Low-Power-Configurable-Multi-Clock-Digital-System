onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate -expand -group TX -color Salmon /tb/DUT/UART_TX_RX/U0_UART_TX/P_DATA
add wave -noupdate -expand -group TX /tb/DUT/UART_TX_RX/U0_UART_TX/Data_Valid
add wave -noupdate -expand -group TX /tb/DUT/UART_TX_RX/U0_UART_TX/clk
add wave -noupdate -expand -group TX /tb/DUT/UART_TX_RX/U0_UART_TX/TX_OUT
add wave -noupdate -expand -group TX /tb/DUT/UART_TX_RX/U0_UART_TX/mux_sel
add wave -noupdate -expand -group TX /tb/DUT/UART_TX_RX/U0_UART_TX/par_bit
add wave -noupdate -expand -group states -color Cyan /tb/DUT/sys_ctrl_u/current_state
add wave -noupdate -expand -group states -color Cyan /tb/DUT/sys_ctrl_u/next_state
add wave -noupdate -expand -group Regfile /tb/DUT/Regfile_u/WrData
add wave -noupdate -expand -group Regfile -format Analog-Step -height 30 -max 88.0 /tb/DUT/Regfile_u/Address
add wave -noupdate -expand -group Regfile /tb/DUT/Regfile_u/WrEn
add wave -noupdate -expand -group Regfile /tb/DUT/Regfile_u/RdEn
add wave -noupdate -expand -group Regfile /tb/DUT/Regfile_u/CLK
add wave -noupdate -expand -group Regfile /tb/DUT/Regfile_u/RdData
add wave -noupdate -expand -group Regfile /tb/DUT/Regfile_u/RdData_VLD
add wave -noupdate -expand -group Regfile /tb/DUT/Regfile_u/REG0
add wave -noupdate -expand -group Regfile /tb/DUT/Regfile_u/REG1
add wave -noupdate -expand -group Regfile /tb/DUT/Regfile_u/REG2
add wave -noupdate -expand -group Regfile /tb/DUT/Regfile_u/REG3
add wave -noupdate -expand -group Regfile /tb/DUT/Regfile_u/i
add wave -noupdate -expand -group SYS_CTRL /tb/DUT/sys_ctrl_u/OUT_VALID
add wave -noupdate -expand -group SYS_CTRL /tb/DUT/sys_ctrl_u/ALU_OUT
add wave -noupdate -expand -group SYS_CTRL /tb/DUT/sys_ctrl_u/RX_P_DATA
add wave -noupdate -expand -group SYS_CTRL /tb/DUT/sys_ctrl_u/RX_D_VLD
add wave -noupdate -expand -group SYS_CTRL /tb/DUT/sys_ctrl_u/fifo_full
add wave -noupdate -expand -group SYS_CTRL /tb/DUT/sys_ctrl_u/ALU_FUN
add wave -noupdate -expand -group SYS_CTRL -color Yellow /tb/DUT/sys_ctrl_u/TX_P_DATA
add wave -noupdate -expand -group SYS_CTRL -color Yellow /tb/DUT/sys_ctrl_u/TX_D_VLD
add wave -noupdate -expand -group FIFO /tb/DUT/FIFO_u/w_ptr_synch
add wave -noupdate -expand -group FIFO /tb/DUT/FIFO_u/w_clken
add wave -noupdate -expand -group FIFO /tb/DUT/FIFO_u/full_w
add wave -noupdate -expand -group FIFO /tb/DUT/FIFO_u/empty_w
add wave -noupdate -expand -group RX /tb/DUT/UART_TX_RX/U0_UART_RX/Prescale
add wave -noupdate -expand -group RX /tb/DUT/UART_TX_RX/U0_UART_RX/clk
add wave -noupdate -expand -group RX /tb/DUT/UART_TX_RX/U0_UART_RX/P_DATA
add wave -noupdate -expand -group RX /tb/DUT/UART_TX_RX/U0_UART_RX/Data_Valid
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {1458146390 ps} 0}
quietly wave cursor active 1
configure wave -namecolwidth 150
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 1
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ps
update
WaveRestoreZoom {1394449312 ps} {1781634167 ps}
